#pragma once

struct DivideByZeroError {
	float numerator;
} divideByZeroError;

//this is an example for catching unexpected errors in the cpp file
struct RandomDivisionError
	{} randomDivisionError;
